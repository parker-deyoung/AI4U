import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Calendar, Clock, MapPin, Users, Briefcase, Lightbulb, Info } from "lucide-react";

export default function JoinSection() {
  const communityFeatures = [
    "Meeting reminders and agenda details",
    "Links to tools and tutorials",
    "Direct networking with peers",
    "Job postings and competitions"
  ];

  return (
    <section id="join" className="py-20" data-testid="join-section">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-6" data-testid="join-title">📢 Ready to Get Involved?</h2>
          <p className="text-xl text-muted-foreground" data-testid="join-subtitle">
            Join us and start your journey into AI, regardless of your background
          </p>
        </div>

        <div className="max-w-4xl mx-auto">
          <div className="grid md:grid-cols-2 gap-12">
            {/* Meeting Details */}
            <div className="bg-primary/10 p-8 rounded-2xl" data-testid="meeting-details">
              <h3 className="text-2xl font-bold mb-6 flex items-center" data-testid="meeting-details-title">
                <span className="mr-3">📍</span>
                Meeting Details
              </h3>
              <div className="space-y-4">
                <div className="flex items-center space-x-4" data-testid="meeting-when-detail">
                  <div className="w-10 h-10 bg-primary/20 rounded-lg flex items-center justify-center">
                    <Calendar className="w-5 h-5 text-primary" />
                  </div>
                  <div>
                    <p className="font-semibold">When</p>
                    <p className="text-muted-foreground">Every Wednesday</p>
                  </div>
                </div>
                
                <div className="flex items-center space-x-4" data-testid="meeting-time-detail">
                  <div className="w-10 h-10 bg-primary/20 rounded-lg flex items-center justify-center">
                    <Clock className="w-5 h-5 text-primary" />
                  </div>
                  <div>
                    <p className="font-semibold">Time</p>
                    <p className="text-muted-foreground">6:00 PM - 7:30 PM</p>
                  </div>
                </div>
                
                <div className="flex items-center space-x-4" data-testid="meeting-location-detail">
                  <div className="w-10 h-10 bg-primary/20 rounded-lg flex items-center justify-center">
                    <MapPin className="w-5 h-5 text-primary" />
                  </div>
                  <div>
                    <p className="font-semibold">Where</p>
                    <p className="text-muted-foreground">Spencer Fox Eccles Business Building (SFEBB), Room 5160A</p>
                    <p className="text-sm text-primary">Always check GroupMe for confirmation!</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Digital Community */}
            <Card className="p-8 shadow-lg" data-testid="digital-community">
              <h3 className="text-2xl font-bold mb-6 flex items-center" data-testid="community-title">
                <span className="mr-3">💬</span>
                Join Our Digital Community
              </h3>
              <p className="text-muted-foreground mb-6" data-testid="community-description">
                Our primary hub for conversation, questions, announcements, and resource sharing is GroupMe.
              </p>
              
              <div className="space-y-3 mb-6">
                {communityFeatures.map((feature, index) => (
                  <div key={index} className="flex items-center space-x-2" data-testid={`community-feature-${index}`}>
                    <div className="w-2 h-2 bg-primary rounded-full"></div>
                    <span className="text-sm">{feature}</span>
                  </div>
                ))}
              </div>
              
              <Button 
                asChild
                className="w-full bg-primary text-primary-foreground hover:bg-primary/90"
                data-testid="join-groupme-button"
              >
                <a href="https://campusconnect.utah.edu/AI4U/club_signup" target="_blank" rel="noopener noreferrer">
                  Join GroupMe Community
                </a>
              </Button>
            </Card>
          </div>

          {/* Call to Action */}
          <div className="mt-16 text-center bg-gradient-to-r from-primary/10 to-destructive/10 p-12 rounded-2xl" data-testid="call-to-action">
            <h3 className="text-3xl font-bold mb-4" data-testid="cta-title">Ready to Shape the Future?</h3>
            <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto" data-testid="cta-description">
              AI4u is about empowering you. Come learn, experiment, and build the future with us.
            </p>
            <div className="flex flex-col md:flex-row gap-4 justify-center">
              <Button 
                asChild
                className="bg-primary text-primary-foreground px-8 py-4 text-lg font-medium hover:bg-primary/90"
                data-testid="join-meeting-button"
              >
                <a href="https://campusconnect.utah.edu/AI4U/club_signup" target="_blank" rel="noopener noreferrer">
                  Join Our Next Meeting
                </a>
              </Button>
              <Button 
                asChild
                variant="outline"
                className="border-primary text-primary px-8 py-4 text-lg font-medium hover:bg-primary/10"
                data-testid="contact-leadership-button"
              >
                <a href="mailto:phdeyoung@gmail.com">
                  Contact Leadership
                </a>
              </Button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
