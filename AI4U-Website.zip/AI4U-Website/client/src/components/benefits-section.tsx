import { Card } from "@/components/ui/card";
import { Briefcase, TrendingUp, Settings } from "lucide-react";

export default function BenefitsSection() {
  const departmentBenefits = [
    {
      department: "Business",
      subdepartment: "Management",
      icon: Briefcase,
      iconColor: "bg-blue-100",
      focusArea: "Agentic Workflows & APIs",
      focusColor: "bg-primary/10 text-primary",
      benefits: "Design and deploy custom AI workflows to automate financial analysis and market research, leading to accelerated decision-making and operational efficiency."
    },
    {
      department: "Marketing",
      subdepartment: "Communications",
      icon: TrendingUp,
      iconColor: "bg-green-100",
      focusArea: "Generative Media",
      focusColor: "bg-green-100 text-green-800",
      benefits: "Master generative media tools for rapid creation and iteration of high-quality, targeted content including images, ad copy, and video scripts for campaigns."
    },
    {
      department: "Information Systems",
      subdepartment: "Technology",
      icon: Settings,
      iconColor: "bg-purple-100",
      focusArea: "Local Models & GPU",
      focusColor: "bg-purple-100 text-purple-800",
      benefits: "Practical experience managing, fine-tuning, and deploying local models with GPU infrastructure for enterprise AI systems requiring privacy and specialized resources."
    }
  ];

  return (
    <section id="benefits" className="py-20 bg-muted/50" data-testid="benefits-section">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-6" data-testid="benefits-title">🎯 Interdisciplinary Impact</h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto" data-testid="benefits-subtitle">
            AI's greatest impact is felt beyond code. We ensure every student has the tools to apply AI in their chosen field.
          </p>
        </div>

        <Card className="rounded-2xl shadow-lg overflow-hidden" data-testid="benefits-table">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-primary/10">
                <tr>
                  <th className="text-left p-6 font-semibold" data-testid="table-header-department">Department</th>
                  <th className="text-left p-6 font-semibold" data-testid="table-header-focus">AI4u Focus Area</th>
                  <th className="text-left p-6 font-semibold" data-testid="table-header-benefits">Specific Benefits</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {departmentBenefits.map((benefit, index) => {
                  const IconComponent = benefit.icon;
                  return (
                    <tr key={index} className="hover:bg-muted/30 transition-colors" data-testid={`benefit-row-${index}`}>
                      <td className="p-6">
                        <div className="flex items-center space-x-3">
                          <div className={`w-10 h-10 ${benefit.iconColor} rounded-lg flex items-center justify-center`}>
                            <IconComponent className="w-5 h-5" />
                          </div>
                          <div>
                            <div className="font-semibold" data-testid={`department-name-${index}`}>{benefit.department}</div>
                            <div className="text-sm text-muted-foreground" data-testid={`subdepartment-name-${index}`}>{benefit.subdepartment}</div>
                          </div>
                        </div>
                      </td>
                      <td className="p-6">
                        <span className={`${benefit.focusColor} px-3 py-1 rounded-full text-sm font-medium`} data-testid={`focus-area-${index}`}>
                          {benefit.focusArea}
                        </span>
                      </td>
                      <td className="p-6 text-sm" data-testid={`benefit-description-${index}`}>
                        {benefit.benefits}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </Card>

        <div className="mt-12 text-center">
          <p className="text-lg text-muted-foreground" data-testid="diversity-message">
            <strong>Our strength lies in diversity.</strong> When students from film, chemistry, and computer science collaborate on AI projects, the resulting innovation is truly transformative.
          </p>
        </div>
      </div>
    </section>
  );
}
