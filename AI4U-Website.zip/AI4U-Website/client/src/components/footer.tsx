import logoImage from "@assets/AI logo Final_1759175306869.jpeg";
import { Instagram, Linkedin, Users, Mail } from "lucide-react";

export default function Footer() {
  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <footer className="bg-muted py-12" data-testid="footer">
      <div className="container mx-auto px-6">
        <div className="grid md:grid-cols-4 gap-8">
          <div data-testid="footer-branding">
            <div className="flex items-center space-x-3 mb-4">
              <img src={logoImage} alt="AI4u Logo" className="w-12 h-12 object-contain" />
              <div>
                <h3 className="text-xl font-bold text-primary">AI4u</h3>
                <p className="text-sm text-muted-foreground">University of Utah</p>
              </div>
            </div>
            <p className="text-muted-foreground mb-4" data-testid="footer-description">
              Building an inclusive AI community for students of all backgrounds.
            </p>
            <div className="flex space-x-4" data-testid="footer-social">
              <a 
                href="https://www.instagram.com/ai4utah/" 
                target="_blank" 
                rel="noopener noreferrer"
                className="text-muted-foreground hover:text-primary transition-colors"
                data-testid="social-instagram"
                aria-label="Instagram"
              >
                <Instagram className="w-6 h-6" />
              </a>
              <a 
                href="https://www.linkedin.com/company/artificial-intelligence-for-u" 
                target="_blank" 
                rel="noopener noreferrer"
                className="text-muted-foreground hover:text-primary transition-colors"
                data-testid="social-linkedin"
                aria-label="LinkedIn"
              >
                <Linkedin className="w-6 h-6" />
              </a>
              <a 
                href="https://groupme.com/join_group/109136781/Tibh81vx" 
                target="_blank" 
                rel="noopener noreferrer"
                className="text-muted-foreground hover:text-primary transition-colors"
                data-testid="social-groupme"
                aria-label="GroupMe"
              >
                <Users className="w-6 h-6" />
              </a>
            </div>
          </div>
          
          <div data-testid="footer-links">
            <h4 className="font-semibold mb-3">Quick Links</h4>
            <div className="space-y-2">
              <button 
                onClick={() => scrollToSection('about')}
                className="block text-muted-foreground hover:text-primary transition-colors"
                data-testid="footer-link-about"
              >
                About
              </button>
              <button 
                onClick={() => scrollToSection('activities')}
                className="block text-muted-foreground hover:text-primary transition-colors"
                data-testid="footer-link-activities"
              >
                Activities
              </button>
              <button 
                onClick={() => scrollToSection('events')}
                className="block text-muted-foreground hover:text-primary transition-colors"
                data-testid="footer-link-events"
              >
                Events
              </button>
              <button 
                onClick={() => scrollToSection('join')}
                className="block text-muted-foreground hover:text-primary transition-colors"
                data-testid="footer-link-join"
              >
                Join Us
              </button>
            </div>
          </div>
          
          <div data-testid="footer-focus-areas">
            <h4 className="font-semibold mb-3">Focus Areas</h4>
            <div className="space-y-2">
              <span className="block text-muted-foreground">LLMs & Prompting</span>
              <span className="block text-muted-foreground">Agentic Workflows</span>
              <span className="block text-muted-foreground">Generative Media</span>
              <span className="block text-muted-foreground">Local Models</span>
            </div>
          </div>
          
          <div data-testid="footer-contact">
            <h4 className="font-semibold mb-3">Contact</h4>
            <div className="space-y-2">
              <p className="text-muted-foreground">Wednesdays 6:00-7:30 PM</p>
              <p className="text-muted-foreground">SFEBB 5160A</p>
              <p className="text-muted-foreground">University of Utah</p>
              <div className="mt-4 pt-4 border-t border-border">
                <p className="text-sm font-semibold mb-2">Leadership Contact</p>
                <a 
                  href="mailto:phdeyoung@gmail.com"
                  className="flex items-center space-x-2 text-muted-foreground hover:text-primary transition-colors"
                  data-testid="contact-leadership-email"
                >
                  <Mail className="w-4 h-4" />
                  <span className="text-sm">phdeyoung@gmail.com</span>
                </a>
              </div>
            </div>
          </div>
        </div>
        
        <div className="border-t border-border mt-8 pt-8 text-center">
          <p className="text-muted-foreground" data-testid="footer-copyright">
            © 2024 AI4u - University of Utah. Building the future of AI education.
          </p>
        </div>
      </div>
    </footer>
  );
}
