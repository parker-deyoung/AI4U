import { Card } from "@/components/ui/card";
import { GraduationCap, Scale, Sprout } from "lucide-react";

export default function EthicsSection() {
  const ethicalPrinciples = [
    {
      icon: GraduationCap,
      iconColor: "bg-blue-100",
      title: "Academic Integrity",
      description: "Our tools are meant to augment, assist, and accelerate learning—not replace it. We explicitly prohibit using AI to cheat or bypass the spirit of academic honesty."
    },
    {
      icon: Scale,
      iconColor: "bg-green-100",
      title: "Intellectual Property",
      description: "We teach best practices for sourcing information, respecting copyrights, and properly attributing AI-generated outputs. We advocate for originality and legal compliance."
    },
    {
      icon: Sprout,
      iconColor: "bg-purple-100",
      title: "Growth Mindset",
      description: "By embracing innovation while maintaining ethical rigor, we ensure every student has access to the knowledge needed to thrive as a responsible AI user."
    }
  ];

  return (
    <section id="ethics" className="py-20 bg-muted/50" data-testid="ethics-section">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-6" data-testid="ethics-title">⚖️ Ethics & Values</h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto" data-testid="ethics-subtitle">
            With great power comes great responsibility. We're committed to fostering ethical and informed AI contributors.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div data-testid="ethics-image">
            <img 
              src="https://images.unsplash.com/photo-1451187580459-43490279c0fa?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600" 
              alt="Digital ethics and responsible AI development concepts" 
              className="rounded-xl shadow-lg w-full h-auto"
            />
          </div>
          <div className="space-y-8">
            {ethicalPrinciples.map((principle, index) => {
              const IconComponent = principle.icon;
              return (
                <Card key={index} className="p-6 shadow-lg" data-testid={`ethics-principle-${index}`}>
                  <div className="flex items-start space-x-4">
                    <div className={`w-12 h-12 ${principle.iconColor} rounded-lg flex items-center justify-center flex-shrink-0`}>
                      <IconComponent className="w-6 h-6" />
                    </div>
                    <div>
                      <h3 className="text-xl font-bold mb-3" data-testid={`principle-title-${index}`}>{principle.title}</h3>
                      <p className="text-muted-foreground" data-testid={`principle-description-${index}`}>{principle.description}</p>
                    </div>
                  </div>
                </Card>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}
