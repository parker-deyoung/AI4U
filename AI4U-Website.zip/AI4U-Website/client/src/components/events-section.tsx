import { Card } from "@/components/ui/card";
import { Clock, MapPin, Info, Calendar, Users, Briefcase, Lightbulb, Target } from "lucide-react";

export default function EventsSection() {
  const meetingFeatures = [
    { icon: Users, title: "Introductions", description: "Meet fellow AI enthusiasts" },
    { icon: Briefcase, title: "Open Positions", description: "Leadership opportunities" },
    { icon: Lightbulb, title: "Networking", description: "Connect with peers" },
    { icon: Info, title: "Information", description: "Club overview & resources" }
  ];

  return (
    <section id="events" className="py-20" data-testid="events-section">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-6" data-testid="events-title">📅 Upcoming Events</h2>
          <p className="text-xl text-muted-foreground" data-testid="events-subtitle">
            Join us for regular meetings, workshops, and special guest speakers
          </p>
        </div>

        <div className="mb-12">
          {/* Regular Meeting Card */}
          <div className="bg-gradient-to-br from-primary/10 to-destructive/10 p-8 rounded-2xl max-w-2xl mx-auto" data-testid="regular-meetings">
            <div className="flex items-start justify-between mb-6">
              <div>
                <h3 className="text-2xl font-bold mb-2" data-testid="regular-meetings-title">Weekly Meetings</h3>
                <p className="text-muted-foreground">Regular club sessions</p>
              </div>
              <div className="text-4xl">🗓️</div>
            </div>
            <div className="space-y-4">
              <div className="flex items-center space-x-3" data-testid="meeting-when">
                <Clock className="w-5 h-5 text-primary" />
                <span><strong>When:</strong> Every Wednesday, 6:00 PM - 7:30 PM</span>
              </div>
              <div className="flex items-center space-x-3" data-testid="meeting-where">
                <MapPin className="w-5 h-5 text-primary" />
                <span><strong>Where:</strong> SFEBB 5160A</span>
              </div>
              <div className="flex items-center space-x-3" data-testid="meeting-note">
                <Info className="w-5 h-5 text-primary" />
                <span>Check GroupMe for room confirmations</span>
              </div>
            </div>
          </div>
        </div>

        {/* Meeting Info */}
        <Card className="p-8 text-center mb-16" data-testid="meeting-expectations">
          <h3 className="text-2xl font-bold mb-4" data-testid="expectations-title">What to Expect</h3>
          <div className="grid md:grid-cols-4 gap-6">
            {meetingFeatures.map((feature, index) => {
              const IconComponent = feature.icon;
              return (
                <div key={index} data-testid={`meeting-feature-${index}`}>
                  <div className="text-3xl mb-3">
                    <IconComponent className="w-8 h-8 mx-auto text-primary" />
                  </div>
                  <h4 className="font-semibold mb-2" data-testid={`feature-title-${index}`}>{feature.title}</h4>
                  <p className="text-sm text-muted-foreground" data-testid={`feature-description-${index}`}>{feature.description}</p>
                </div>
              );
            })}
          </div>
        </Card>

        {/* Previous Events */}
        <div className="text-center mb-12">
          <h2 className="text-4xl md:text-5xl font-bold mb-6" data-testid="previous-events-title">📚 Previous Events</h2>
          <p className="text-xl text-muted-foreground" data-testid="previous-events-subtitle">
            Recent workshops and special sessions
          </p>
        </div>

        <div className="max-w-2xl mx-auto">
          <Card className="p-8 border-2 border-muted/40 opacity-90" data-testid="special-workshop">
            <div className="flex items-start justify-between mb-6">
              <div>
                <h3 className="text-2xl font-bold mb-2" data-testid="workshop-title">Jon Cheney Workshop</h3>
                <p className="text-muted-foreground">Founder of GenAPI</p>
              </div>
              <div className="text-4xl">🚀</div>
            </div>
            <div className="space-y-4 mb-6">
              <h4 className="text-lg font-semibold text-primary" data-testid="workshop-topic">
                "How to Build a Business in a Weekend With AI"
              </h4>
              <div className="space-y-2 text-sm">
                <div className="flex items-center space-x-2" data-testid="workshop-date">
                  <div className="w-2 h-2 bg-primary rounded-full"></div>
                  <span><strong>Date:</strong> September 24/25</span>
                </div>
                <div className="flex items-center space-x-2" data-testid="workshop-time">
                  <div className="w-2 h-2 bg-primary rounded-full"></div>
                  <span><strong>Time:</strong> 6:00 PM</span>
                </div>
                <div className="flex items-center space-x-2" data-testid="workshop-location">
                  <div className="w-2 h-2 bg-primary rounded-full"></div>
                  <span><strong>Location:</strong> SFEBB 110</span>
                </div>
                <div className="flex items-center space-x-2" data-testid="workshop-focus">
                  <div className="w-2 h-2 bg-primary rounded-full"></div>
                  <span><strong>Focus:</strong> Hands-on Skills</span>
                </div>
              </div>
            </div>
            <div className="bg-muted/50 p-4 rounded-lg">
              <p className="text-sm text-muted-foreground font-medium" data-testid="workshop-highlight">
                🎯 Special hands-on workshop with industry expert
              </p>
            </div>
          </Card>
        </div>
      </div>
    </section>
  );
}
