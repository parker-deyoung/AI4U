import { Card } from "@/components/ui/card";

export default function ActivitiesSection() {
  const weeklyActivities = [
    {
      emoji: "🕹️",
      title: "Prompt Playground",
      description: "Master the foundations of prompt engineering through guided, interactive sessions. From basics to advanced techniques like few-shot prompting.",
      features: [
        "LLM communication basics",
        "Advanced prompting techniques",
        "System-level instructions"
      ]
    },
    {
      emoji: "🚢",
      title: "Setup & Ship",
      description: "Overcome technical hurdles of AI experimentation. From cloud environments to local tools and hardware understanding.",
      features: [
        "Cloud compute setup",
        "API access and configuration",
        "GPU requirements"
      ]
    },
    {
      emoji: "⏰",
      title: "20-Minute Build",
      description: "Fast-paced collaborative challenges to foster creativity and rapid prototyping with generative AI tools.",
      features: [
        "Rapid prototyping skills",
        "Creative collaboration",
        "Immediate results"
      ]
    }
  ];

  return (
    <section id="activities" className="py-20" data-testid="activities-section">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-6" data-testid="activities-title">🤝 Learn, Build, Connect</h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto" data-testid="activities-subtitle">
            Our activities are designed to be accessible, informative, and immediately useful, providing both industry context and hands-on experience.
          </p>
        </div>

        {/* Monthly Speaker Series */}
        <div className="mb-16">
          <div className="bg-gradient-to-r from-primary/10 to-destructive/10 p-8 md:p-12 rounded-2xl" data-testid="speaker-series">
            <div className="grid md:grid-cols-2 gap-8 items-center">
              <div>
                <h3 className="text-3xl font-bold mb-4 flex items-center" data-testid="speaker-series-title">
                  🎤 Monthly Industry Speaker Series
                </h3>
                <p className="text-lg text-muted-foreground mb-6" data-testid="speaker-series-description">
                  Connect with industry professionals and U of U staff actively working with AI. These sessions provide invaluable exposure to real-world applications, career paths, and emerging trends.
                </p>
                <ul className="space-y-2">
                  <li className="flex items-center space-x-2" data-testid="speaker-benefit-networking">
                    <div className="w-2 h-2 bg-primary rounded-full"></div>
                    <span>Direct networking opportunities</span>
                  </li>
                  <li className="flex items-center space-x-2" data-testid="speaker-benefit-applications">
                    <div className="w-2 h-2 bg-primary rounded-full"></div>
                    <span>Real-world AI applications</span>
                  </li>
                  <li className="flex items-center space-x-2" data-testid="speaker-benefit-careers">
                    <div className="w-2 h-2 bg-primary rounded-full"></div>
                    <span>Career path insights</span>
                  </li>
                </ul>
              </div>
              <div>
                <img 
                  src="https://images.unsplash.com/photo-1560472354-b33ff0c44a43?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600" 
                  alt="Professional speaker presenting to engaged audience" 
                  className="rounded-lg w-full h-auto shadow-lg"
                  data-testid="speaker-image"
                />
              </div>
            </div>
          </div>
        </div>

        {/* Weekly Sessions */}
        <div className="grid lg:grid-cols-3 gap-8">
          {weeklyActivities.map((activity, index) => (
            <Card key={index} className="p-8 shadow-lg" data-testid={`activity-card-${index}`}>
              <div className="text-4xl mb-4" data-testid={`activity-emoji-${index}`}>{activity.emoji}</div>
              <h3 className="text-2xl font-bold mb-4" data-testid={`activity-title-${index}`}>{activity.title}</h3>
              <p className="text-muted-foreground mb-6" data-testid={`activity-description-${index}`}>{activity.description}</p>
              <div className="space-y-2 text-sm">
                {activity.features.map((feature, featureIndex) => (
                  <div key={featureIndex} className="flex items-center space-x-2" data-testid={`activity-feature-${index}-${featureIndex}`}>
                    <div className="w-1.5 h-1.5 bg-primary rounded-full"></div>
                    <span>{feature}</span>
                  </div>
                ))}
              </div>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
