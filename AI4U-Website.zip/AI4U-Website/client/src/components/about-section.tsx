import { Card } from "@/components/ui/card";
import { MessageSquare, Zap, Palette, Cpu, Link, Users } from "lucide-react";

export default function AboutSection() {
  const focusAreas = [
    {
      icon: MessageSquare,
      title: "Prompting & LLMs",
      description: "Master effective communication with ChatGPT, Gemini, and Claude for research, coding, and creative work."
    },
    {
      icon: Zap,
      title: "Agentic Workflows",
      description: "Create sophisticated multi-step systems where AI autonomously handles complex tasks like market analysis."
    },
    {
      icon: Palette,
      title: "Generative Media",
      description: "Hands-on creation of images, video, music, and text using cutting-edge generative AI tools."
    },
    {
      icon: Cpu,
      title: "Local Models & GPU",
      description: "Understanding infrastructure for running, fine-tuning, and deploying specialized AI models locally."
    },
    {
      icon: Link,
      title: "APIs Integration",
      description: "Connect AI services to external applications, websites, apps, and data pipelines."
    },
    {
      icon: Users,
      title: "Interdisciplinary Focus",
      description: "Collaborative projects combining diverse academic backgrounds for transformative innovation."
    }
  ];

  return (
    <section id="about" className="py-20 bg-muted/50" data-testid="about-section">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-6" data-testid="about-title">Our Mission</h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto" data-testid="about-subtitle">
            AI for Everyone - We believe AI transcends traditional academic boundaries and is essential for success across every modern discipline.
          </p>
        </div>
        
        <div className="grid md:grid-cols-2 gap-12 items-center mb-16">
          <div>
            <h3 className="text-3xl font-bold mb-6 text-primary" data-testid="inclusive-learning-title">💡 Inclusive Learning</h3>
            <p className="text-lg text-muted-foreground mb-6" data-testid="inclusive-learning-description">
              We recognize that AI is no longer just for computer science majors. Our community welcomes students from marketing and fine arts to medicine and management, providing education and resources needed to thrive in our rapidly changing technological world.
            </p>
            <ul className="space-y-3">
              <li className="flex items-start space-x-3" data-testid="feature-backgrounds">
                <div className="w-2 h-2 bg-primary rounded-full mt-2.5"></div>
                <span>All backgrounds and experience levels welcome</span>
              </li>
              <li className="flex items-start space-x-3" data-testid="feature-practical">
                <div className="w-2 h-2 bg-primary rounded-full mt-2.5"></div>
                <span>Practical tools for immediate application</span>
              </li>
              <li className="flex items-start space-x-3" data-testid="feature-adaptive">
                <div className="w-2 h-2 bg-primary rounded-full mt-2.5"></div>
                <span>Adaptive curriculum based on technology advances</span>
              </li>
            </ul>
          </div>
          <div className="bg-card p-8 rounded-xl shadow-lg" data-testid="collaboration-image">
            <img 
              src="https://images.unsplash.com/photo-1522202176988-66273c2fd55f?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600" 
              alt="Diverse students collaborating on AI projects" 
              className="rounded-lg w-full h-auto"
            />
          </div>
        </div>

        <div className="mb-16">
          <h3 className="text-3xl font-bold mb-12 text-center" data-testid="focus-areas-title">🧠 Our Focus Areas</h3>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {focusAreas.map((area, index) => {
              const IconComponent = area.icon;
              return (
                <Card key={index} className="p-8 hover:shadow-xl transition-shadow" data-testid={`focus-area-${index}`}>
                  <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                    <IconComponent className="w-6 h-6 text-primary" />
                  </div>
                  <h4 className="text-xl font-semibold mb-3" data-testid={`focus-area-title-${index}`}>{area.title}</h4>
                  <p className="text-muted-foreground" data-testid={`focus-area-description-${index}`}>{area.description}</p>
                </Card>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}
