import { Clock, MapPin } from "lucide-react";
import { Button } from "@/components/ui/button";
import logoImage from "@assets/AI logo Final_1759175306869.jpeg";

export default function HeroSection() {
  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section className="relative min-h-screen flex items-center justify-center hero-pattern" data-testid="hero-section">
      <div className="absolute inset-0 gradient-bg"></div>
      <div className="container mx-auto px-6 text-center relative z-10">
        <div className="max-w-4xl mx-auto">
          <div className="mx-auto mb-8 float-animation" style={{width: '120px', height: '120px'}} data-testid="hero-brain-icon">
            <img src={logoImage} alt="AI4u Logo" className="w-full h-full object-contain" />
          </div>
          <h1 className="text-5xl md:text-7xl font-bold mb-6 bg-gradient-to-r from-primary to-destructive bg-clip-text text-transparent" data-testid="hero-title">
            AI4u
          </h1>
          <p className="text-xl md:text-2xl text-muted-foreground mb-4" data-testid="hero-subtitle">
            Artificial Intelligence for the U Community
          </p>
          <p className="text-lg md:text-xl text-muted-foreground mb-8 max-w-2xl mx-auto" data-testid="hero-description">
            Building an inclusive and dynamic community for learning, experimenting with, and critically discussing AI technologies across all disciplines.
          </p>
          <div className="flex flex-col md:flex-row gap-4 justify-center items-center">
            <Button 
              asChild
              className="bg-primary text-primary-foreground px-8 py-4 text-lg font-medium hover:bg-primary/90"
              data-testid="hero-join-button"
            >
              <a href="https://campusconnect.utah.edu/AI4U/club_signup" target="_blank" rel="noopener noreferrer">
                Join Our Community
              </a>
            </Button>
            <Button 
              variant="outline"
              onClick={() => scrollToSection('about')}
              className="border-border px-8 py-4 text-lg font-medium hover:bg-muted"
              data-testid="hero-learn-button"
            >
              Learn More
            </Button>
          </div>
          <div className="mt-12 flex flex-col md:flex-row justify-center items-center gap-4 md:gap-8 text-sm text-muted-foreground">
            <div className="flex items-center space-x-2" data-testid="hero-meeting-time">
              <Clock className="w-5 h-5" />
              <span>Wednesdays 6:00-7:30 PM</span>
            </div>
            <div className="flex items-center space-x-2" data-testid="hero-meeting-location">
              <MapPin className="w-5 h-5" />
              <span>SFEBB 5160A</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
