import { useState } from "react";
import { Menu, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import logoImage from "@assets/AI logo Final_1759175306869.jpeg";

export default function Navigation() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
    setIsMenuOpen(false);
  };

  return (
    <nav className="sticky top-0 z-50 bg-background/95 backdrop-blur-sm border-b border-border" data-testid="navigation">
      <div className="container mx-auto px-6 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3" data-testid="logo">
            <img src={logoImage} alt="AI4u Logo" className="w-12 h-12 object-contain" />
            <div>
              <h1 className="text-2xl font-bold text-primary">AI4u</h1>
              <p className="text-xs text-muted-foreground">University of Utah</p>
            </div>
          </div>
          
          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-8">
            <button 
              onClick={() => scrollToSection('about')}
              className="text-foreground hover:text-primary transition-colors"
              data-testid="nav-about"
            >
              About
            </button>
            <button 
              onClick={() => scrollToSection('activities')}
              className="text-foreground hover:text-primary transition-colors"
              data-testid="nav-activities"
            >
              Activities
            </button>
            <button 
              onClick={() => scrollToSection('benefits')}
              className="text-foreground hover:text-primary transition-colors"
              data-testid="nav-benefits"
            >
              Benefits
            </button>
            <button 
              onClick={() => scrollToSection('events')}
              className="text-foreground hover:text-primary transition-colors"
              data-testid="nav-events"
            >
              Events
            </button>
            <button 
              onClick={() => scrollToSection('ethics')}
              className="text-foreground hover:text-primary transition-colors"
              data-testid="nav-ethics"
            >
              Ethics
            </button>
            <Button 
              asChild
              className="bg-primary text-primary-foreground hover:bg-primary/90"
              data-testid="nav-join"
            >
              <a href="https://campusconnect.utah.edu/AI4U/club_signup" target="_blank" rel="noopener noreferrer">
                Join Us
              </a>
            </Button>
          </div>

          {/* Mobile Menu Button */}
          <Button
            variant="ghost"
            size="icon"
            className="md:hidden"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            data-testid="mobile-menu-toggle"
          >
            {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </Button>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <div className="md:hidden mt-4 pb-4 space-y-2" data-testid="mobile-menu">
            <button 
              onClick={() => scrollToSection('about')}
              className="block w-full text-left py-2 text-foreground hover:text-primary transition-colors"
              data-testid="mobile-nav-about"
            >
              About
            </button>
            <button 
              onClick={() => scrollToSection('activities')}
              className="block w-full text-left py-2 text-foreground hover:text-primary transition-colors"
              data-testid="mobile-nav-activities"
            >
              Activities
            </button>
            <button 
              onClick={() => scrollToSection('benefits')}
              className="block w-full text-left py-2 text-foreground hover:text-primary transition-colors"
              data-testid="mobile-nav-benefits"
            >
              Benefits
            </button>
            <button 
              onClick={() => scrollToSection('events')}
              className="block w-full text-left py-2 text-foreground hover:text-primary transition-colors"
              data-testid="mobile-nav-events"
            >
              Events
            </button>
            <button 
              onClick={() => scrollToSection('ethics')}
              className="block w-full text-left py-2 text-foreground hover:text-primary transition-colors"
              data-testid="mobile-nav-ethics"
            >
              Ethics
            </button>
            <Button 
              asChild
              className="w-full mt-4 bg-primary text-primary-foreground hover:bg-primary/90"
              data-testid="mobile-nav-join"
            >
              <a href="https://campusconnect.utah.edu/AI4U/club_signup" target="_blank" rel="noopener noreferrer">
                Join Us
              </a>
            </Button>
          </div>
        )}
      </div>
    </nav>
  );
}
