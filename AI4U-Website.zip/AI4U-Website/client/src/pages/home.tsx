import Navigation from "@/components/navigation";
import HeroSection from "@/components/hero-section";
import AboutSection from "@/components/about-section";
import ActivitiesSection from "@/components/activities-section";
import BenefitsSection from "@/components/benefits-section";
import EventsSection from "@/components/events-section";
import EthicsSection from "@/components/ethics-section";
import JoinSection from "@/components/join-section";
import Footer from "@/components/footer";

export default function Home() {
  return (
    <div className="min-h-screen">
      <Navigation />
      <HeroSection />
      <AboutSection />
      <ActivitiesSection />
      <BenefitsSection />
      <EventsSection />
      <EthicsSection />
      <JoinSection />
      <Footer />
    </div>
  );
}
