import { type User, type InsertUser, type Event, type InsertEvent } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  getEvents(): Promise<Event[]>;
  getEvent(id: string): Promise<Event | undefined>;
  createEvent(event: InsertEvent): Promise<Event>;
  updateEvent(id: string, event: Partial<InsertEvent>): Promise<Event | undefined>;
  deleteEvent(id: string): Promise<boolean>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private events: Map<string, Event>;

  constructor() {
    this.users = new Map();
    this.events = new Map();
    
    // Initialize with some default events
    this.initializeDefaultEvents();
  }

  private initializeDefaultEvents() {
    const defaultEvents: InsertEvent[] = [
      {
        title: "Weekly AI4u Meeting",
        description: "Regular club session with introductions, networking, and AI discussions",
        date: new Date("2024-10-02T18:00:00"),
        location: "SFEBB 5160A",
        speaker: null,
        eventType: "regular"
      },
      {
        title: "Jon Cheney Workshop: How to Build a Business in a Weekend With AI",
        description: "Special hands-on workshop with GenAPI founder focusing on practical business applications",
        date: new Date("2024-09-24T18:00:00"),
        location: "SFEBB 110",
        speaker: "Jon Cheney - Founder of GenAPI",
        eventType: "workshop"
      }
    ];

    defaultEvents.forEach(event => {
      const id = randomUUID();
      const eventWithId: Event = { 
        ...event, 
        id,
        description: event.description ?? null,
        speaker: event.speaker ?? null
      };
      this.events.set(id, eventWithId);
    });
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async getEvents(): Promise<Event[]> {
    return Array.from(this.events.values()).sort((a, b) => 
      new Date(a.date).getTime() - new Date(b.date).getTime()
    );
  }

  async getEvent(id: string): Promise<Event | undefined> {
    return this.events.get(id);
  }

  async createEvent(insertEvent: InsertEvent): Promise<Event> {
    const id = randomUUID();
    const event: Event = { 
      ...insertEvent, 
      id,
      description: insertEvent.description ?? null,
      speaker: insertEvent.speaker ?? null
    };
    this.events.set(id, event);
    return event;
  }

  async updateEvent(id: string, updateData: Partial<InsertEvent>): Promise<Event | undefined> {
    const existingEvent = this.events.get(id);
    if (!existingEvent) {
      return undefined;
    }
    
    const updatedEvent: Event = { ...existingEvent, ...updateData };
    this.events.set(id, updatedEvent);
    return updatedEvent;
  }

  async deleteEvent(id: string): Promise<boolean> {
    return this.events.delete(id);
  }
}

export const storage = new MemStorage();
